<?

if (isset($requiredLogin)) {
    if ($requiredLogin) {

        if (!isset($_SESSION['admin_loggedin']) || $_SESSION['admin_loggedin'] == "0") {
            header("Location: ../login");
        }

    }
}

?>